<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Hifz Academy</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Open+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-light px- px-lg-5 py-5 py-lg-0">
                <a href="index.html" class="navbar-brand p-0">
                    <h1 class="m-0"><img src="img/logo.png">Hifz-Academy</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="index.html" class="nav-item nav-link">Home</a>
                        <a href="course.php" class="nav-item nav-link">Courses</a>
                        <a href="pricing.php" class="nav-item nav-link">Pricing</a>
                        <a href="#touch" class="nav-item nav-link">Get In Touch</a>
                       <!-- <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <a href="team.html" class="dropdown-item">Our Team</a>
                                <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                                <a href="comparison.html" class="dropdown-item">Comparison</a>
                            </div>
                        </div>
                        <a href="contact.html" class="nav-item nav-link">Contact</a>-->
                    </div>
                    </div>
            </nav>

            <div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 pt-5">
                        <div class="col-12 text-center text-lg-start">
                            <h1 class="display-4 text-white animated slideInLeft">Pricing Plans</h1>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb justify-content-center justify-content-lg-start animated slideInLeft">
                                    <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>
                                    <li class="breadcrumb-item"><a class="text-white" href="pricing.php">Pricing</a></li>
                                    <li class="breadcrumb-item text-white active" aria-current="page">60 Minutes Class</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

        <!-- Pricing Start -->
        <div class="container-xxl py-5">
            <div class="container px-lg-5">
                <div class="section-title position-relative text-center mx-auto mb-5 pb-4 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">60 Minutes Class Learning Packages</h1>
                    <p class="mb-1">Discover the Hifz Academy's Learning Packages, crafted for efficient Quranic memorization. Elevate your spiritual journey with our focused and personalized programs.</p>
                </div>
                <div class="custom-container blinking bg-secondary text-white text-center py-2 rounded">
                <h2 class="mb-2 heading">Sale! Enroll Now and Save</h2>
                <p class="lead para">Save 30% on all packages For Just 2 Months</p>
            </div>

               <div class="row gy-5 gx-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
                        <div class="position-relative shadow rounded border-top border-5 border-primary">
                            <div class="d-flex align-items-center justify-content-center position-absolute top-0 start-50 translate-middle bg-primary rounded-circle" style="width: 45px; height: 45px; margin-top: -3px;">
                                <i class="fa fa-server text-white"></i>
                            </div>
                            <div class="text-center border-bottom p-4 pt-5">
                                <h4 class="fw-bold">Basic Package</h4>
                                <p class="mb-0">Hifz Academy's Learning Packages</p>
                            </div>
                            <div class="text-center border-bottom p-4">
                                <p class="text-primary mb-1">Latest Offer - <strong>Save 30%</strong></p>
                                <h1 class="mb-3">
                                    <del class="text-muted me-2" style="font-size: 25px; line-height: 35px;">$60</del>
                                    <strong style="font-size: 40px; line-height: 25px;">$42</strong>
                                    <small style="font-size: 14px; line-height: 30px;">/ Month</small>
                                </h1>

                                <a class="btn btn-primary px-4 py-2" href="test.php">Enroll Now</a>
                            </div>
                            <div class="p-4">
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>Time Duration 60 Min</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>2 Classes per Week</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>8 Classes per Month</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="position-relative shadow rounded border-top border-5 border-secondary">
                            <div class="d-flex align-items-center justify-content-center position-absolute top-0 start-50 translate-middle bg-secondary rounded-circle" style="width: 45px; height: 45px; margin-top: -3px;">
                                <i class="fa fa-pen text-white"></i>
                            </div>
                            <div class="text-center border-bottom p-4 pt-5">
                                <h4 class="fw-bold">Silver Package</h4>
                                <p class="mb-0">Hifz Academy's Learning Packages</p>
                            </div>
                            <div class="text-center border-bottom p-4">
                                <p class="text-primary mb-1">Latest Offer - <strong>Save 30%</strong></p>
                                <h1 class="mb-3">
                                    <del class="text-muted me-2" style="font-size: 25px; line-height: 35px;">$90</del>
                                    <strong style="font-size: 40px; line-height: 25px;">$63</strong>
                                    <small style="font-size: 14px; line-height: 30px;">/ Month</small>
                                </h1>

                                <a class="btn btn-secondary px-4 py-2" href="test.php">Enroll Now</a>
                            </div>
                            <div class="p-4">
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>Time Duration 60 Min</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>3 Classes per Week</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>12 Classes per Month</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
                        <div class="position-relative shadow rounded border-top border-5 border-primary">
                            <div class="d-flex align-items-center justify-content-center position-absolute top-0 start-50 translate-middle bg-primary rounded-circle" style="width: 45px; height: 45px; margin-top: -3px;">
                                <i class="fa fa-book text-white"></i>
                            </div>
                            <div class="text-center border-bottom p-4 pt-5">
                                <h4 class="fw-bold">Golden Package</h4>
                                <p class="mb-0">Hifz Academy's Learning Packages</p>
                            </div>
                            <div class="text-center border-bottom p-4">
                                <p class="text-primary mb-1">Latest Offer - <strong>Save 30%</strong></p>
                                <h1 class="mb-3">
                                    <del class="text-muted me-2" style="font-size: 25px; line-height: 35px;">$120</del>
                                    <strong style="font-size: 40px; line-height: 25px;">$84</strong>
                                    <small style="font-size: 14px; line-height: 30px;">/ Month</small>
                                </h1>

                                <a class="btn btn-primary px-4 py-2" href="test.php">Enroll Now</a>
                            </div>
                            <div class="p-4">
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>Time Duration 60 Min</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>4 Classes per Week</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>16 Classes per Month</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="position-relative shadow rounded border-top border-5 border-secondary">
                            <div class="d-flex align-items-center justify-content-center position-absolute top-0 start-50 translate-middle bg-secondary rounded-circle" style="width: 45px; height: 45px; margin-top: -3px;">
                                <i class="fa fa-plane text-white"></i>
                            </div>
                            <div class="text-center border-bottom p-4 pt-5">
                                <h4 class="fw-bold">Diamond Package</h4>
                                <p class="mb-0">Hifz Academy's Learning Packages</p>
                            </div>
                            <div class="text-center border-bottom p-4">
                                <p class="text-primary mb-1">Latest Offer - <strong>Save 30%</strong></p>
                                <h1 class="mb-3">
                                    <del class="text-muted me-2" style="font-size: 25px; line-height: 35px;">$150</del>
                                    <strong style="font-size: 35px; line-height: 25px;">$105</strong>
                                    <small style="font-size: 14px; line-height: 30px;">/ Month</small>
                                </h1>

                                <a class="btn btn-secondary px-4 py-2" href="test.php">Enroll Now</a>
                            </div>
                            <div class="p-4">
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>Time Duration 60 Min</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>5 Classes per Week</p>
                                <p class="border-bottom pb-3"><i class="fa fa-check text-primary me-3"></i>20 Classes per Month</p>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <!-- Pricing End -->
  
       
        

<!-- Footer Start -->
<div class="container-fluid bg-danger text-white footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
                <div class="container py-4 px-lg-4">
                    <div class="pt-4 row gy-4 gx-3 pt-4">
                        <div class="col-lg-5 col-md-12">
                            <div class="row gy-5 g-4">
                                <div class="col-md-6">
                                    <h5 class="fw-bold text-white mb-2">Our Courses</h5>
                                    <a class="btn btn-link" href="course.php">Quran Memorization</a>
                                    <a class="btn btn-link" href="course.php">Nazra with Tajweed</a>
                                    <a class="btn btn-link" href="course.php">Quran Translation</a>
                                    <a class="btn btn-link" href="course.php">Tafseer</a>
                                    <a class="btn btn-link" href="course.php">Arabic Grammar</a>
                                    <a class="btn btn-link" href="course.php">Masnoon Prayers</a>
                                </div>
                                <div class="col-md-6">
                                    <h5 class="fw-bold text-white mb-2" id="touch">Get In Touch</h5>
                                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+92 313 0515240</p>
                                    <p class="mb-4"><i class="fa fa-envelope me-3"></i>hifzacademy00@gmail.com</p>
                                    <h5 class="fw-bold text-white mb-2" id="touch">Payment Methods</h5>
                                    <p class="mb-2"><i class="fas fa-dollar-sign  me-3"></i>Western Union</p>
                                    <p class="mb-2"><i class="far fa-credit-card me-3"></i>AlFalah Bank</p>
                                    <p class="mb-2"><i class="fas fa-question me-3"></i>Other Banks</p>
                            
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mt-lg-n5">
                        <img class="img-fluid animated zoomIn" src="img/footer design.png" alt="" style="max-width: 250px;">
                    </div>
                    </div>
                </div>
                <div class="container px-lg-5">
                    <div class="copyright">
                        <div class="row">
                            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                                &copy; Hifz Academy, All Right Reserved.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <!-- Footer End -->



        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-secondary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>