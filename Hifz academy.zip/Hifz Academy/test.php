<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment Form</title>

    <!-- Add Bootstrap CSS from CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <style>
        /* Style for success and danger messages */
        .alert-success,
        .alert-danger {
            margin-top: 10px;
        }

        /* Light Green Theme */
        .light-green-bg {
            background-color: #8bc34a; /* Light Green */
        }

        .custom-label {
            color: white;
        }

        .custom-form-group {
            margin-bottom: 15px;
        }

        .custom-btn {
            background-color: #f44336; /* Light Green */
            color: white;
            border-radius: 5px;
        }

        .custom-btn:hover {
            background-color: #689f38; /* Darker Green on Hover */
        }

        /* Customize input fields */
        .form-control {
            border: none; /* Remove border */
            border-radius: 15px; /* Rounded corners */
            color: #333; /* Text color for better contrast */
        }

        /* Change placeholder color for better visibility */
        ::placeholder {
            color: #666;
        }

        /* Adjust form width */
        #enrollmentForm {
            max-width: 500px;
            margin: 0 auto;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        #formTitle {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
            color: white;
        }

        .container {
            max-width: 600px;
            border-radius: 25px;
        }
    </style>

</head>

<body class="">

    <!-- Enrollment Form -->
    <div class="light-green-bg container mt-4 mb-2">
        <form id="enrollmentForm">
            <div id="formTitle">Hifz Academy Enrollment Form</div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="firstName" class="custom-label">First Name:</label>
                    <input type="text" class="form-control" id="firstName" placeholder="Enter First Name" required>
                </div>
                <div class="col">
                    <label for="lastName" class="custom-label">Last Name:</label>
                    <input type="text" class="form-control" id="lastName" placeholder="Enter Last Name" required>
                </div>
            </div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="fatherName" class="custom-label">Father's Name:</label>
                    <input type="text" class="form-control" id="fatherName" placeholder="Enter Father's Name" required>
                </div>
            </div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="email" class="custom-label">Email:</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter Your Email" required>
                </div>
            </div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="age" class="custom-label">Age:</label>
                    <input type="number" class="form-control" id="age" placeholder="Enter Your Age" required>
                </div>
                <div class="col">
                    <label for="gender" class="custom-label">Gender:</label>
                    <select class="form-control" id="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="prefer-not-say">Prefer Not to Say</option>
                    </select>
                </div>
            </div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="country" class="custom-label">Country:</label>
                    <input type="text" class="form-control" id="country" placeholder="Enter Your Country" required>
                </div>
                <div class="col">
                    <label for="contact" class="custom-label">Contact:</label>
                    <input type="text" class="form-control" id="contact" placeholder="Enter Your Contact Number" required>
                </div>
            </div>
            <div class="form-row custom-form-group">
                <div class="col">
                    <label for="course" class="custom-label">Course:</label>
                    <select class="form-control" id="course">
                        <option value="course1">Course 1</option>
                        <option value="course2">Course 2</option>
                        <option value="course3">Course 3</option>
                        <option value="course4">Course 4</option>
                    </select>
                </div>
                <div class="col">
                    <label for="classTime" class="custom-label">Class Time:</label>
                    <select class="form-control" id="classTime">
                        <option value="30min">30 Minutes</option>
                        <option value="45min">45 Minutes</option>
                        <option value="60min">60 Minutes</option>
                    </select>
                </div>
                <div class="col">
                    <label for="package" class="custom-label">Package:</label>
                    <select class="form-control" id="package">
                        <option value="basic">Basic</option>
                        <option value="silver">Silver</option>
                        <option value="golden">Golden</option>
                        <option value="diamond">Diamond</option>
                    </select>
                </div>
            </div>

            <div class="alert" role="alert" id="enrollmentResult"></div>
            <button type="button" class="btn custom-btn" onclick="sendWhatsAppMessage()">Submit</button>
        </form>
    </div>

    <!-- Add Bootstrap JS and Popper.js from CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script>
    function sendWhatsAppMessage() {
        // Get form data using querySelector
        var firstName = document.querySelector('#firstName').value;
        var lastName = document.querySelector('#lastName').value;
        var fatherName = document.querySelector('#fatherName').value;
        var email = document.querySelector('#email').value;
        var age = document.querySelector('#age').value;
        var gender = document.querySelector('#gender').value;
        var country = document.querySelector('#country').value;
        var contact = document.querySelector('#contact').value;
        var course = document.querySelector('#course').value;
        var classTime = document.querySelector('#classTime').value;
        var package = document.querySelector('#package').value;

        // Check if all fields are filled
        if (
            !firstName ||
            !lastName ||
            !fatherName ||
            !email ||
            !age ||
            !gender ||
            !country ||
            !contact ||
            !course ||
            !classTime ||
            !package
        ) {
            // Display error message
            document.getElementById('enrollmentResult').classList.remove('alert-success');
            document.getElementById('enrollmentResult').classList.add('alert-danger');
            document.getElementById('enrollmentResult').innerHTML = 'Please fill in all the fields.';
            return; // Do not submit the form if fields are not filled
        }

        // Create a WhatsApp message with properly encoded content
        var whatsappMessage = `Enrollment Details:%0A%0AName: ${encodeURIComponent(firstName + ' ' + lastName)}%0AFather's Name: ${encodeURIComponent(fatherName)}%0AEmail: ${encodeURIComponent(email)}%0AAge: ${encodeURIComponent(age)}%0AGender: ${encodeURIComponent(gender)}%0ACountry: ${encodeURIComponent(country)}%0AContact: ${encodeURIComponent(contact)}%0ACourse: ${encodeURIComponent(course)}%0AClass Time: ${encodeURIComponent(classTime)}%0APackage: ${encodeURIComponent(package)}`;

        // Create a WhatsApp link
        var whatsappLink = `https://wa.me/923130515240?text=${whatsappMessage}`;

        // Open WhatsApp in a new tab with the pre-filled message
        window.open(whatsappLink, '_blank').focus();

        // Display success message
        document.getElementById('enrollmentResult').classList.remove('alert-danger');
        document.getElementById('enrollmentResult').classList.add('alert-success');
        document.getElementById('enrollmentResult').innerHTML = 'Enrollment submitted successfully!';
    }
</script>


</body>

</html>
